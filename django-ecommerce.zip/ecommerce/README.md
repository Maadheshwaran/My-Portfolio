# ShopEasy — Django E-Commerce Demo

A functional e-commerce site built with Django, vanilla HTML/CSS/JS.

## Features
- Product listing with category filter and search
- Product detail pages
- Session-based shopping cart (add / update quantity / remove)
- Checkout form -> Order creation -> stock deduction -> confirmation page
- Django admin for managing products, categories, and orders

## Setup

1. Create a virtual environment and install dependencies:
   ```
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Run migrations:
   ```
   python manage.py migrate
   ```

3. Seed sample products (12 products across 4 categories):
   ```
   python manage.py seed_data
   ```

4. Create an admin account:
   ```
   python manage.py createsuperuser
   ```

5. Run the dev server:
   ```
   python manage.py runserver
   ```

6. Visit:
   - Store: http://127.0.0.1:8000/
   - Admin: http://127.0.0.1:8000/admin/

## Project Structure
```
ecommerce/
  ecommerce/        # project settings, urls
  store/
    models.py        # Category, Product, Order, OrderItem
    views.py          # product list/detail, cart, checkout
    cart.py            # session-based cart class
    forms.py            # OrderCreateForm, CartAddProductForm
    admin.py              # Django admin registration
    templates/store/        # HTML templates
    static/store/             # CSS / JS
    management/commands/seed_data.py   # sample data loader
```

## Notes
- Cart data is stored in the Django session (no login required to shop).
- Placing an order deducts stock and marks the order as paid (demo checkout — no real payment gateway is integrated).
- Swap SQLite for Postgres/MySQL in `ecommerce/settings.py` `DATABASES` for production use.

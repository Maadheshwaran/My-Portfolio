// Small client-side enhancements for the cart and checkout flows.
document.addEventListener("DOMContentLoaded", function () {
    // Auto-dismiss alert messages after a few seconds
    document.querySelectorAll(".alert").forEach(function (alertEl) {
        setTimeout(function () {
            alertEl.style.transition = "opacity 0.4s";
            alertEl.style.opacity = "0";
            setTimeout(function () { alertEl.remove(); }, 400);
        }, 4000);
    });

    // Confirm before removing an item from the cart
    document.querySelectorAll(".btn-remove").forEach(function (btn) {
        btn.addEventListener("click", function (e) {
            if (!confirm("Remove this item from your cart?")) {
                e.preventDefault();
            }
        });
    });
});

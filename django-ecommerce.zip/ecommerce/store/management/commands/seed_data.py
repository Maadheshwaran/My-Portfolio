from django.core.management.base import BaseCommand
from store.models import Category, Product


class Command(BaseCommand):
    help = "Seed the database with sample categories and products."

    def handle(self, *args, **options):
        categories_data = {
            "electronics": "Electronics",
            "clothing": "Clothing",
            "home-kitchen": "Home & Kitchen",
            "books": "Books",
        }
        categories = {}
        for slug, name in categories_data.items():
            cat, _ = Category.objects.get_or_create(slug=slug, defaults={"name": name})
            categories[slug] = cat

        products = [
            ("Wireless Headphones", "electronics", 79.99, 25,
             "Over-ear wireless headphones with noise cancellation and 30-hour battery life.",
             "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600"),
            ("Smart Watch", "electronics", 129.99, 15,
             "Fitness-tracking smart watch with heart-rate monitor and GPS.",
             "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600"),
            ("Bluetooth Speaker", "electronics", 45.50, 40,
             "Portable waterproof speaker with rich bass and 12-hour playback.",
             "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600"),
            ("Cotton T-Shirt", "clothing", 14.99, 100,
             "Soft, breathable 100% cotton t-shirt available in multiple colors.",
             "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600"),
            ("Denim Jacket", "clothing", 59.99, 30,
             "Classic denim jacket with a comfortable regular fit.",
             "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600"),
            ("Running Shoes", "clothing", 89.99, 20,
             "Lightweight running shoes with cushioned soles for everyday training.",
             "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600"),
            ("Non-Stick Frying Pan", "home-kitchen", 24.99, 50,
             "10-inch non-stick frying pan, dishwasher safe and oven friendly.",
             "https://images.unsplash.com/photo-1584990347449-a40e9293c83b?w=600"),
            ("Ceramic Coffee Mug Set", "home-kitchen", 19.99, 60,
             "Set of 4 ceramic mugs, microwave and dishwasher safe.",
             "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=600"),
            ("LED Desk Lamp", "home-kitchen", 32.00, 35,
             "Adjustable LED desk lamp with 3 brightness levels and USB charging port.",
             "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600"),
            ("The Art of Clean Code", "books", 22.50, 45,
             "A practical guide to writing maintainable, readable software.",
             "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600"),
            ("Mystery at Midnight", "books", 12.99, 0,
             "A gripping mystery novel that keeps you guessing until the final page.",
             "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600"),
            ("Cooking for Beginners", "books", 16.75, 28,
             "Easy step-by-step recipes for anyone just starting out in the kitchen.",
             "https://images.unsplash.com/photo-1495195134817-aeb325a55b65?w=600"),
        ]

        created = 0
        for name, cat_slug, price, stock, desc, img in products:
            slug = name.lower().replace(" ", "-").replace("&", "and")
            _, was_created = Product.objects.get_or_create(
                slug=slug,
                defaults={
                    "name": name,
                    "category": categories[cat_slug],
                    "price": price,
                    "stock": stock,
                    "description": desc,
                    "image_url": img,
                    "available": True,
                },
            )
            if was_created:
                created += 1

        self.stdout.write(self.style.SUCCESS(f"Seed complete. {created} new products created."))

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.views.decorators.http import require_POST

from .models import Category, Product, Order, OrderItem
from .cart import Cart
from .forms import OrderCreateForm, CartAddProductForm


def product_list(request, category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)

    query = request.GET.get("q")
    if query:
        products = products.filter(name__icontains=query)

    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)

    return render(
        request,
        "store/product_list.html",
        {"category": category, "categories": categories, "products": products, "query": query or ""},
    )


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, available=True)
    cart_product_form = CartAddProductForm()
    related_products = Product.objects.filter(category=product.category, available=True).exclude(id=product.id)[:4]
    return render(
        request,
        "store/product_detail.html",
        {"product": product, "cart_product_form": cart_product_form, "related_products": related_products},
    )


@require_POST
def cart_add(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    form = CartAddProductForm(request.POST)
    if form.is_valid():
        cd = form.cleaned_data
        cart.add(product=product, quantity=cd["quantity"])
        messages.success(request, f"Added {product.name} to your cart.")
    return redirect("store:cart_detail")


@require_POST
def cart_remove(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart.remove(product)
    messages.info(request, f"Removed {product.name} from your cart.")
    return redirect("store:cart_detail")


@require_POST
def cart_update(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    try:
        quantity = int(request.POST.get("quantity", 1))
    except (TypeError, ValueError):
        quantity = 1
    if quantity < 1:
        cart.remove(product)
    else:
        cart.add(product=product, quantity=quantity, update_quantity=True)
    return redirect("store:cart_detail")


def cart_detail(request):
    cart = Cart(request)
    return render(request, "store/cart_detail.html", {"cart": cart})


def order_create(request):
    cart = Cart(request)
    if len(cart) == 0:
        messages.warning(request, "Your cart is empty. Add a product before checking out.")
        return redirect("store:product_list")

    if request.method == "POST":
        form = OrderCreateForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.status = "paid"
            order.paid = True
            order.save()
            for item in cart:
                OrderItem.objects.create(
                    order=order,
                    product=item["product"],
                    price=item["price"],
                    quantity=item["quantity"],
                )
                # reduce stock
                product = item["product"]
                product.stock = max(product.stock - item["quantity"], 0)
                product.save()
            cart.clear()
            return redirect("store:order_success", order_id=order.id)
    else:
        form = OrderCreateForm()

    return render(request, "store/order_create.html", {"cart": cart, "form": form})


def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, "store/order_success.html", {"order": order})

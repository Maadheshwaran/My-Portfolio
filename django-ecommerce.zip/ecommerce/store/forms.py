from django import forms
from .models import Order


class OrderCreateForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ["full_name", "email", "address", "city", "postal_code"]
        widgets = {
            "full_name": forms.TextInput(attrs={"placeholder": "Full name", "class": "form-input"}),
            "email": forms.EmailInput(attrs={"placeholder": "Email address", "class": "form-input"}),
            "address": forms.TextInput(attrs={"placeholder": "Street address", "class": "form-input"}),
            "city": forms.TextInput(attrs={"placeholder": "City", "class": "form-input"}),
            "postal_code": forms.TextInput(attrs={"placeholder": "Postal code", "class": "form-input"}),
        }


class CartAddProductForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, max_value=50, initial=1, widget=forms.NumberInput(attrs={"class": "qty-input"}))
